const Stripe = require("stripe");

exports.handler = async (event) => {
  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
  const items = JSON.parse(event.body);

  const line_items = items.map((item) => ({
    price_data: {
      currency: "eur",
      product_data: { name: item.name },
      unit_amount: item.price,
    },
    quantity: 1,
  }));

  const session = await stripe.checkout.sessions.create({
    payment_method_types: ["card"],
    line_items,
    mode: "payment",
    success_url: "https://your-site.netlify.app/success",
    cancel_url: "https://your-site.netlify.app",
  });

  return {
    statusCode: 200,
    body: JSON.stringify({ url: session.url }),
  };
};
