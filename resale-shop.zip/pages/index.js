import { useState } from "react";
import products from "../lib/products";

export default function Home() {
  const [cart, setCart] = useState([]);

  const addToCart = (product) => {
    setCart([...cart, product]);
  };

  const checkout = async () => {
    const res = await fetch("/.netlify/functions/checkout", {
      method: "POST",
      body: JSON.stringify(cart),
    });
    const data = await res.json();
    window.location.href = data.url;
  };

  return (
    <div style={{padding:20}}>
      <h1>Resale Store</h1>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
        {products.map((p) => (
          <div key={p.id} style={{background:"#1a1a1a",padding:10}}>
            <img src={p.image} style={{width:"100%"}} />
            <h2>{p.name}</h2>
            <p>€{(p.price / 100).toFixed(2)}</p>
            <p>{p.condition}</p>
            <button onClick={() => addToCart(p)}>Add</button>
          </div>
        ))}
      </div>

      {cart.length > 0 && (
        <button onClick={checkout}>
          Checkout ({cart.length})
        </button>
      )}
    </div>
  );
}
